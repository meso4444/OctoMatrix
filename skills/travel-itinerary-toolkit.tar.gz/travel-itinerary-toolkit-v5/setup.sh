#!/bin/bash

# Markdown to PDF - One-Click Setup Script
# Installs all dependencies and creates ready-to-use environment

set -e

echo "🚀 Markdown to PDF - Setup"
echo "================================"

# Detect OS
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    OS="linux"
elif [[ "$OSTYPE" == "darwin"* ]]; then
    OS="macos"
elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "cygwin" ]]; then
    OS="windows"
else
    OS="unknown"
fi

echo "✓ Detected OS: $OS"

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "📦 Installing Node.js..."

    if [ "$OS" = "linux" ]; then
        curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
        sudo apt-get install -y nodejs
    elif [ "$OS" = "macos" ]; then
        if ! command -v brew &> /dev/null; then
            echo "Installing Homebrew..."
            /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
        fi
        brew install node
    else
        echo "❌ Please install Node.js manually: https://nodejs.org/"
        exit 1
    fi
fi

NODE_VERSION=$(node --version)
echo "✓ Node.js: $NODE_VERSION"

# Check npm
if ! command -v npm &> /dev/null; then
    echo "❌ npm not found. Please reinstall Node.js"
    exit 1
fi

NPM_VERSION=$(npm --version)
echo "✓ npm: $NPM_VERSION"

# Install system libraries for Chrome on Linux
if [ "$OS" = "linux" ]; then
    echo "📦 Installing Chrome dependencies..."
    sudo apt-get update
    sudo apt-get install -y \
        libatk1.0-0 \
        libatk-bridge2.0-0 \
        libcups2 \
        libxcomposite1 \
        libxdamage1 \
        libatspi2.0-0 \
        libx11-xcb1 \
        libxss1 2>/dev/null || true
    echo "✓ Chrome dependencies installed"
fi

# Install CJK fonts
if [ "$OS" = "linux" ]; then
    echo "📦 Installing CJK fonts..."
    sudo apt-get install -y fonts-noto-cjk 2>/dev/null || true
    fc-cache -f -v 2>/dev/null || true
    echo "✓ CJK fonts installed"
elif [ "$OS" = "macos" ]; then
    echo "📦 Installing CJK fonts (macOS)..."
    brew tap homebrew/cask-fonts 2>/dev/null || true
    brew install font-noto-sans-cjk 2>/dev/null || true
    echo "✓ CJK fonts ready"
fi

# Install npm dependencies
echo "📦 Installing npm dependencies..."
npm install
echo "✓ Dependencies installed"

# Create wrapper script
echo "📝 Creating md2pdf command wrapper..."
cat > md2pdf << 'SCRIPT'
#!/bin/bash
node "$(dirname "$0")/scripts/markdown_to_pdf_browser.js" "$@"
SCRIPT

chmod +x md2pdf
echo "✓ Wrapper script created"

# Verify installation
echo ""
echo "✅ Setup Complete!"
echo ""
echo "Ready to use:"
echo "  ./pdf input.md output.pdf"
echo ""
echo "Example:"
echo "  ./pdf README.md readme.pdf"
echo ""
echo "For help:"
echo "  ./pdf --help"
echo ""
