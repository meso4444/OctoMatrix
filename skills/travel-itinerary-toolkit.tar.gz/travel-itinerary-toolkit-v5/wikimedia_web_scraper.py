#!/usr/bin/env python3
"""
🌍 Wikimedia 網頁搜尋爬取工具（簡潔版）
直接搜尋網頁而非 API

核心原則：
✅ 用當地語言搜尋（日文、韓文、中文...）
✅ 直接從 Wikimedia 網頁提取圖片
✅ URL 編碼處理
✅ 簡單有效
"""

import urllib.request
import urllib.parse
import urllib.error
import re
import time
import sys

class WikimediaWebScraper:
    """簡單的網頁爬取工具"""

    def __init__(self):
        self.session_delay = 2

    def search_commons(self, local_language_name):
        """
        搜尋 Wikimedia Commons（網頁版）

        Args:
            local_language_name: 景點當地語言名稱

        返回：(搜尋 URL, 網頁內容) 或 (None, None)
        """
        print(f"   🔍 搜尋: {local_language_name}", end='', flush=True)

        try:
            # 構建 Wikimedia 搜尋 URL
            encoded_name = urllib.parse.quote(local_language_name.encode('utf-8'))
            search_url = f"https://commons.wikimedia.org/w/index.php?search={encoded_name}&title=Special%3AMediaSearch&type=image"

            # 取得網頁
            req = urllib.request.Request(
                search_url,
                headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
            )

            with urllib.request.urlopen(req, timeout=10) as response:
                html_content = response.read().decode('utf-8')
                print(f" ✓")
                return search_url, html_content

        except Exception as e:
            print(f" ❌ ({str(e)[:30]})")
            return None, None

    def extract_images_from_html(self, html_content):
        """
        從 HTML 提取圖片 URL

        Args:
            html_content: Wikimedia 搜尋結果 HTML

        返回：圖片 URL 列表
        """
        images = []

        # 尋找圖片資源連結
        # Wikimedia 搜尋結果包含圖片縮圖
        pattern = r'src="([^"]*?commons\.wikimedia\.org[^"]*?)"'
        matches = re.findall(pattern, html_content)

        if matches:
            # 去重和過濾
            seen = set()
            for url in matches:
                # 只取実際的圖片 URL（去掉縮圖參數）
                if 'thumb' in url or 'wikipedia' in url:
                    # 提取原始圖片 URL
                    base_url = re.sub(r'/thumb/', '/', url)
                    base_url = re.sub(r'/\d+px-[^/]*\.jpg.*', '.jpg', base_url)

                    if base_url not in seen and 'commons.wikimedia' in base_url:
                        seen.add(base_url)
                        images.append(base_url)

        return images[:10]  # 返回前 10 個

    def extract_file_urls(self, html_content):
        """
        從 HTML 提取 File: 連結

        返回：檔案 URL 列表
        """
        files = []

        # 尋找 File: 連結
        pattern = r'href="([^"]*?commons\.wikimedia\.org/wiki/File:[^"]*?)"'
        matches = re.findall(pattern, html_content)

        seen = set()
        for url in matches:
            if url not in seen:
                seen.add(url)
                files.append(url)

        return files[:10]

    def get_image_url_from_file_page(self, file_url):
        """
        從檔案頁面取得實際圖片 URL（優先使用縮圖 URL 以避免速率限制）

        Args:
            file_url: File: 頁面 URL

        返回：圖片 URL 或 None
        """
        try:
            time.sleep(1.5)  # 增加延遲以避免速率限制
            req = urllib.request.Request(
                file_url,
                headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
            )

            with urllib.request.urlopen(req, timeout=10) as response:
                html = response.read().decode('utf-8')

                # 優先查找完整的縮圖 URL（包含尺寸信息）
                # 格式：commons/thumb/X/XX/filename/500px-filename.jpg
                thumb_full_pattern = r'(https://upload\.wikimedia\.org/wikipedia/commons/thumb/[^"]*?/\d+px-[^"]*?\.(jpg|jpeg|png))'
                thumb_full_matches = re.findall(thumb_full_pattern, html, re.IGNORECASE)

                if thumb_full_matches:
                    return thumb_full_matches[0][0]

                # 備選：查找任何有尺寸的縮圖 URL
                thumb_any_pattern = r'(https://upload\.wikimedia\.org/wikipedia/commons/thumb/[^"]*?/(?:\d+px-)?[^"]*?\.(jpg|jpeg|png))'
                thumb_any_matches = re.findall(thumb_any_pattern, html, re.IGNORECASE)

                # 過濾並修復不完整的 URL
                for match_tuple in thumb_any_matches:
                    url = match_tuple[0]

                    # 如果 URL 不以副檔名結尾，嘗試從 HTML 中提取完整版本
                    if not re.search(r'\.(jpg|jpeg|png)$', url, re.IGNORECASE):
                        # 查找帶有完整副檔名的版本
                        filename = url.split('/')[-1]
                        full_pattern = f'(https://upload\\.wikimedia\\.org/wikipedia/commons/thumb/.*?/{re.escape(filename)}[^"]*?\\.(?:jpg|jpeg|png))'
                        full_matches = re.findall(full_pattern, html, re.IGNORECASE)
                        if full_matches:
                            return full_matches[0]
                    else:
                        return url

                # 最後手段：查找原始檔案 URL（避免速率限制）
                # 只有在無其他選擇時才使用
                pattern = r'(https://upload\.wikimedia\.org/wikipedia/commons/[^/]*?/[^/]*?/[^"]*?\.(jpg|jpeg|png))'
                matches = re.findall(pattern, html, re.IGNORECASE)

                if matches:
                    for match in matches:
                        url = match[0]
                        if '/thumb/' not in url:
                            return url

            return None

        except Exception as e:
            return None

    def find_attraction_images(self, attraction_name):
        """
        完整流程：搜尋 → 提取 → 驗證

        Args:
            attraction_name: 景點當地語言名稱

        返回：圖片 URL 列表或空列表
        """
        print(f"\n🏯 {attraction_name}")

        # 步驟 1: 搜尋
        search_url, html = self.search_commons(attraction_name)
        if not html:
            return []

        # 步驟 2: 提取檔案連結
        file_urls = self.extract_file_urls(html)
        if not file_urls:
            print(f"   ⚠️  無檔案連結")
            return []

        print(f"   ✓ 找到 {len(file_urls)} 個檔案連結")

        # 步驟 3: 逐個取得圖片 URL
        image_urls = []
        for idx, file_url in enumerate(file_urls[:5], 1):
            file_name = file_url.split('/File:')[-1].replace('%27', "'")
            print(f"     📄 {file_name[:40]}...", end='', flush=True)

            url = self.get_image_url_from_file_page(file_url)
            if url:
                print(f" ✓")
                image_urls.append({
                    'url': url,
                    'filename': file_name,
                    'desc': attraction_name
                })
            else:
                print(f" ❌")

        return image_urls


def main():
    if len(sys.argv) < 2:
        print("用法: python3 wikimedia_web_scraper.py <景點清單文件>")
        print("\n文件格式（任何當地語言，每行一個景點）:")
        print("  白兎神社")
        print("  出雲大社")
        print("  松江城")
        print("  永平寺")
        sys.exit(1)

    input_file = sys.argv[1]

    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            attractions = [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        print(f"❌ 文件不存在: {input_file}")
        sys.exit(1)

    print("╔════════════════════════════════════════════════════════════╗")
    print("║ 🌍 Wikimedia 網頁搜尋爬取工具（簡潔版）                    ║")
    print("║ 直接從網頁提取圖片，支援任何當地語言                      ║")
    print("╚════════════════════════════════════════════════════════════╝")

    scraper = WikimediaWebScraper()

    all_results = {}
    successful = 0
    failed = 0

    for attraction_name in attractions:
        images = scraper.find_attraction_images(attraction_name)
        if images:
            all_results[attraction_name] = images
            successful += 1
        else:
            failed += 1

    print(f"\n╔════════════════════════════════════════════════════════════╗")
    print(f"║ ✅ 成功: {successful:2d}  ❌ 失敗: {failed:2d}                                    ║")
    print(f"╚════════════════════════════════════════════════════════════╝\n")

    # 輸出結果
    print("=== 查詢結果 ===\n")
    for attraction_name, images in all_results.items():
        print(f"✓ {attraction_name} ({len(images)} 張圖片)")
        for img in images[:2]:
            print(f"  • {img['filename'][:50]}")
            print(f"    {img['url'][:70]}...")
        print()

    # 生成用於 image_to_base64_md.py 的輸入
    print("\n=== 用於 image_to_base64_md.py 的輸入 ===\n")
    for attraction_name, images in all_results.items():
        if images:
            img = images[0]  # 用第一張圖片
            print(f"{attraction_name}|{img['url']}")


if __name__ == "__main__":
    main()
