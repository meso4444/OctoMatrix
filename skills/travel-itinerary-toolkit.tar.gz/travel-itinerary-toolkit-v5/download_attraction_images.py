#!/usr/bin/env python3
"""
【腳本】download_attraction_images.py
功能：搜尋景點圖片，下載縮圖預覽
設計原則：完全參數化，無硬編碼
"""

import argparse
import json
import os
import sys
import urllib.request
import urllib.error
import time
from pathlib import Path

sys.path.insert(0, os.path.dirname(__file__))
try:
    from wikimedia_web_scraper import WikimediaWebScraper
except ImportError:
    print("❌ 錯誤：找不到 wikimedia_web_scraper.py")
    sys.exit(1)


class AttractionImageDownloader:
    """景點圖片下載器"""

    def __init__(self, output_dir, num_previews=3, timeout=15, delay=0.5):
        self.scraper = WikimediaWebScraper()
        self.output_dir = output_dir
        self.num_previews = num_previews
        self.timeout = timeout
        self.delay = delay
        self.image_index = {}

    def download_thumbnails(self, attractions):
        """下載縮圖"""
        os.makedirs(self.output_dir, exist_ok=True)
        results = {}
        successful = 0
        failed = 0

        for jp_name, info in attractions.items():
            print(f"🔍 {jp_name:<15}", end='', flush=True)

            try:
                image_list = self.scraper.find_attraction_images(jp_name)

                if not image_list:
                    print(f" ❌ 無圖片")
                    failed += 1
                    continue

                print(f" → 找到 {len(image_list)} 張", end='', flush=True)

                downloaded_images = []
                for idx, img_info in enumerate(image_list[:self.num_previews]):
                    try:
                        url = img_info['url']
                        filename = f"{jp_name}_preview_{idx+1}.jpg"
                        filepath = os.path.join(self.output_dir, filename)

                        req = urllib.request.Request(
                            url,
                            headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
                        )

                        with urllib.request.urlopen(req, timeout=self.timeout) as response:
                            image_data = response.read()

                        with open(filepath, 'wb') as f:
                            f.write(image_data)

                        downloaded_images.append({
                            'idx': idx + 1,
                            'url': url,
                            'filepath': filepath,
                            'size_kb': len(image_data) / 1024,
                            'filename': filename
                        })

                        time.sleep(self.delay)

                    except Exception as e:
                        continue

                if not downloaded_images:
                    print(f" ❌ 縮圖全部下載失敗")
                    failed += 1
                    continue

                results[jp_name] = downloaded_images
                self.image_index[jp_name] = [img['url'] for img in downloaded_images]

                print(f" → 下載 {len(downloaded_images)} 張 ✅")
                successful += 1

            except Exception as e:
                print(f" ❌ 錯誤: {str(e)[:30]}")
                failed += 1

        return results, successful, failed

    def save_index(self, output_file):
        """保存 URL 索引"""
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(self.image_index, f, ensure_ascii=False, indent=2)
        return output_file


def main():
    parser = argparse.ArgumentParser(
        description='【腳本】搜尋景點圖片 + 下載縮圖預覽',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
範例：
  # 基本用法
  python3 download_attraction_images.py attractions.txt ./output/

  # 自訂參數
  python3 download_attraction_images.py \\
    --input attractions.txt \\
    --output ./images/ \\
    --num-previews 5 \\
    --timeout 20 \\
    --delay 1.0 \\
    --index-output ./images/urls.json

景點清單檔案格式（UTF-8，每行一個景點當地語言名稱）：
  白兎神社
  出雲大社
  松江城
        '''
    )

    parser.add_argument(
        'input',
        metavar='INPUT_FILE',
        help='景點清單檔案（必需參數）'
    )

    parser.add_argument(
        'output',
        metavar='OUTPUT_DIR',
        nargs='?',
        default=None,
        help='輸出目錄（默認：./temp_images/）'
    )

    parser.add_argument(
        '--num-previews',
        type=int,
        default=3,
        help='下載縮圖數量（默認：3）'
    )

    parser.add_argument(
        '--timeout',
        type=int,
        default=15,
        help='HTTP 超時時間（秒，默認：15）'
    )

    parser.add_argument(
        '--delay',
        type=float,
        default=0.5,
        help='下載間隔延遲（秒，默認：0.5）'
    )

    parser.add_argument(
        '--index-output',
        type=str,
        default=None,
        help='URL 索引輸出檔案（默認：{OUTPUT_DIR}/image_index.json）'
    )

    args = parser.parse_args()

    # 設定預設值
    input_file = args.input
    output_dir = args.output or './temp_images/'
    index_output = args.index_output or os.path.join(output_dir, 'image_index.json')

    # 驗證輸入檔案
    if not os.path.exists(input_file):
        print(f"❌ 錯誤：景點清單檔案不存在 - {input_file}")
        sys.exit(1)

    # 讀取景點清單
    attractions = {}
    with open(input_file, 'r', encoding='utf-8') as f:
        for line in f:
            name = line.strip()
            if name:
                attractions[name] = {'name': name}

    if not attractions:
        print(f"❌ 錯誤：景點清單為空 - {input_file}")
        sys.exit(1)

    print("╔════════════════════════════════════════╗")
    print("║ 【腳本】下載景點圖片縮圖                ║")
    print("╚════════════════════════════════════════╝\n")

    # 執行下載
    downloader = AttractionImageDownloader(
        output_dir=output_dir,
        num_previews=args.num_previews,
        timeout=args.timeout,
        delay=args.delay
    )

    results, successful, failed = downloader.download_thumbnails(attractions)

    # 保存索引
    downloader.save_index(index_output)

    print(f"\n✓ 下載完成: {successful}/{len(attractions)} 景點")
    print(f"\n📁 輸出：")
    print(f"   縮圖位置: {output_dir}")
    print(f"   索引檔案: {index_output}")

    if failed > 0:
        print(f"\n⚠️  {failed} 個景點無圖片或下載失敗")


if __name__ == "__main__":
    main()
