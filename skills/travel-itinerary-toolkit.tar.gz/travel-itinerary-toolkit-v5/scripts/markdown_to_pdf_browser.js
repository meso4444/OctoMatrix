#!/usr/bin/env node
/**
 * Markdown to PDF via Browser Rendering (HTML → Browser → PDF)
 * 完美支援繁體中文 - 利用瀏覽器原生渲染能力
 */

const fs = require('fs');
const path = require('path');
const puppeteer = require('puppeteer');
const md = require('markdown-it')({
  html: true,
  breaks: true,
  linkify: true
});

async function convertMarkdownToPdf(inputFile, outputFile) {
  console.log('[START] 開始轉換: Markdown → HTML → Browser → PDF');
  console.log(`[INPUT] ${inputFile}`);
  console.log(`[OUTPUT] ${outputFile}`);

  let browser = null;

  try {
    // 步驟 1: 讀取 Markdown
    console.log('[PARSE] 讀取 Markdown...');
    if (!fs.existsSync(inputFile)) {
      throw new Error(`文件不存在: ${inputFile}`);
    }
    const mdContent = fs.readFileSync(inputFile, 'utf-8');
    console.log(`[PARSE] ✓ ${mdContent.length} 字符`);

    // 步驟 2: 轉為 HTML
    console.log('[HTML] 轉換 Markdown → HTML...');
    const htmlContent = md.render(mdContent);

    // 步驟 3: 建立完整 HTML (帶 CSS)
    const fullHtml = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Color+Emoji&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/twemoji@latest/dist/twemoji.min.js" crossorigin="anonymous"></script>
    <style>
        img.emoji {
            height: 1.2em;
            width: 1.2em;
            margin: 0 .05em 0 .1em;
            vertical-align: -0.2em;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        @page {
            margin: 20mm;
            size: A4;
        }

        body {
            font-family: "Noto Sans CJK TC", "Noto Serif CJK TC",
                         "Microsoft JhengHei", "PingFang TC",
                         "Hiragino Sans GB", "Noto Color Emoji", sans-serif;
            line-height: 1.8;
            color: #333;
            font-size: 14px;
        }

        h1 { color: #007bff; border-bottom: 3px solid #007bff; padding-bottom: 10px; margin: 1em 0 0.5em; }
        h2 { color: #0056b3; border-left: 5px solid #0056b3; padding-left: 10px; margin: 1em 0 0.5em; }
        h3 { color: #003d82; margin: 0.8em 0 0.4em; }

        p { margin-bottom: 1em; text-align: justify; }
        ul, ol { margin: 0 0 1em 2em; }
        li { margin-bottom: 0.5em; }

        strong { color: #d9534f; font-weight: bold; }
        em { font-style: italic; color: #5cb85c; }

        code { background: #f5f5f5; padding: 2px 4px; font-size: 0.9em; }
        pre {
            background: #f5f5f5;
            border-left: 4px solid #007bff;
            padding: 1em;
            margin: 1em 0;
            overflow-x: auto;
            page-break-inside: avoid;
        }

        table {
            border-collapse: collapse;
            margin: 1em 0;
            width: 100%;
            page-break-inside: avoid;
        }

        th {
            background: #007bff;
            color: white;
            padding: 8px;
            text-align: left;
            font-weight: bold;
        }

        td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        tr:nth-child(even) { background: #f9f9f9; }

        blockquote {
            border-left: 4px solid #ddd;
            padding-left: 1em;
            margin: 1em 0;
            color: #666;
            font-style: italic;
        }
    </style>
</head>
<body>
    ${htmlContent}
    <script>
        twemoji.parse(document.body);
    </script>
</body>
</html>
    `;

    // 步驟 4: 啟動瀏覽器 (激進的無頭模式)
    console.log('[BROWSER] 啟動 Chrome (激進無頭模式)...');

    browser = await puppeteer.launch({
      headless: 'new',
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-gpu',                    // 禁用 GPU
        '--disable-software-rasterizer',    // 禁用軟件光柵化
        '--disable-extensions',              // 禁用擴展
        '--disable-component-extensions-with-background-pages',
        '--disable-default-apps',
        '--disable-preconnect',
        '--disable-sync',
        '--metrics-recording-only',
        '--mute-audio',
        '--no-first-run',
        '--no-default-browser-check',
        '--disable-background-networking',
        '--disable-client-side-phishing-detection',
        '--disable-hanging-renderer',
        '--disable-popup-blocking',
        '--disable-prompt-on-repost',
        '--disable-renderer-backgrounding',
        '--disable-top-sites',
        '--enable-automation',
        '--password-store=basic',
        '--use-mock-keychain'
      ]
    });

    console.log('[BROWSER] ✓ Chrome 已啟動');

    // 步驟 5: 建立頁面
    console.log('[PAGE] 建立頁面...');
    const page = await browser.newPage();
    await page.setViewport({ width: 1280, height: 800 });
    console.log('[PAGE] ✓ 頁面已建立');

    // 步驟 6: 載入 HTML
    console.log('[LOAD] 載入 HTML 到瀏覽器...');
    await page.setContent(fullHtml, {
      waitUntil: 'networkidle0',
      timeout: 30000
    });
    console.log('[LOAD] ✓ HTML 已載入');

    // 步驟 7: 等待渲染
    console.log('[RENDER] 等待瀏覽器渲染...');
    await new Promise(resolve => setTimeout(resolve, 2000));  // 給瀏覽器充足時間渲染
    console.log('[RENDER] ✓ 渲染完成');

    // 步驟 8: 生成 PDF (使用瀏覽器的列印引擎)
    console.log('[PDF] 通過瀏覽器列印引擎生成 PDF...');
    await page.pdf({
      path: outputFile,
      format: 'A4',
      margin: {
        top: '20mm',
        right: '20mm',
        bottom: '20mm',
        left: '20mm'
      },
      printBackground: true,
      timeout: 30000
    });
    console.log('[PDF] ✓ PDF 已生成');

    // 步驟 9: 關閉瀏覽器
    await browser.close();
    console.log('[BROWSER] ✓ Chrome 已關閉');

    // 步驟 10: 驗證
    console.log('');
    if (fs.existsSync(outputFile)) {
      const sizeKB = (fs.statSync(outputFile).size / 1024).toFixed(1);
      console.log(`[SUCCESS] PDF 生成成功!`);
      console.log(`[SIZE] ${sizeKB} KB`);

      // 驗證中文
      try {
        const { execSync } = require('child_process');
        const text = execSync(`pdftotext "${outputFile}" -`).toString();
        if (text.match(/[一-鿿]/)) {
          console.log(`[VERIFY] ✅ 中文文本驗證通過`);
        }
      } catch (e) {
        // pdftotext 不可用或出錯，不影響成功
      }

      return true;
    } else {
      throw new Error('PDF 文件未生成');
    }

  } catch (error) {
    console.error('[ERROR]', error.message);

    // 詳細的錯誤診斷
    if (error.message.includes('libatk') || error.message.includes('not found')) {
      console.error('');
      console.error('[DIAGNOSIS] 缺失系統庫:');
      console.error('  - libatk-1.0');
      console.error('  - libatk-bridge-2.0');
      console.error('  - libcups');
      console.error('  - libXcomposite');
      console.error('');
      console.error('[SOLUTION] 需要安裝:');
      console.error('  sudo apt-get install libatk1.0-0 libatk-bridge2.0-0 libcups2 libxcomposite1 libxdamage1 libatspi2.0-0');
    }

    if (browser) await browser.close();
    process.exit(1);
  }
}

// 命令行介面
if (process.argv.length < 4) {
  console.log('用法: node markdown_to_pdf_browser.js <input.md> <output.pdf>');
  process.exit(1);
}

convertMarkdownToPdf(process.argv[2], process.argv[3]).then(success => {
  process.exit(success ? 0 : 1);
});
